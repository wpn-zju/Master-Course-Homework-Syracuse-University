package com.peinanweng.firebase

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class RecyclerViewAdapter(val items: ArrayList<MovieList>) :
    RecyclerView.Adapter<RecyclerViewAdapter.MovieViewHolder>() {
    var myListener: MyItemClickListener? = null

    interface MyItemClickListener {
        fun onItemClickedFromAdapter(position: Int)
        fun onItemLongClickedFromAdapter(position: Int)
    }

    fun setMyItemClickListener(listener: MyItemClickListener) {
        this.myListener = listener
    }

    override fun onCreateViewHolder(parent: ViewGroup, position: Int): MovieViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        val view = layoutInflater.inflate(R.layout.movie_item, parent, false)
        return MovieViewHolder(view)
    }

    override fun getItemCount(): Int {
        return items.size
    }

    override fun onBindViewHolder(holder: MovieViewHolder, position: Int) {
        val movie = items[position]
        holder.movieTitle.text = movie.title
        holder.moviePoster.setImageResource(movie.poster_pos!!)
        holder.movieOverview.text = movie.overview
        holder.movieSelect.isChecked = movie.check!!
    }

    override fun getItemViewType(position: Int): Int {
        return position
    }

    inner class MovieViewHolder(view: View) :
        RecyclerView.ViewHolder(view) {
        val moviePoster = view.findViewById<ImageView>(R.id.rvPoster)
        val movieTitle = view.findViewById<TextView>(R.id.rvTitle)
        val movieOverview = view.findViewById<TextView>(R.id.rvOverview)
        val movieSelect = view.findViewById<CheckBox>(R.id.rvCheck)

        init {
            view.setOnClickListener {
                if (myListener != null) {
                    if (adapterPosition !=
                        RecyclerView.NO_POSITION
                    ) {
                        myListener!!.onItemClickedFromAdapter(adapterPosition)
                    }
                }
            }
            view.setOnLongClickListener {
                if (myListener != null) {
                    if (adapterPosition !=
                        RecyclerView.NO_POSITION
                    ) {
                        myListener!!.onItemLongClickedFromAdapter(adapterPosition)
                    }
                }
                true
            }
        }
    }
}
