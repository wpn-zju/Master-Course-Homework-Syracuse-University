package com.peinanweng.firebase

import com.fasterxml.jackson.annotation.JsonIgnoreProperties
import java.io.Serializable

@JsonIgnoreProperties("selection")
class Movie : Serializable {

    var name: String = ""
    var description: String = ""
    var director: String = ""
    var id: String = ""
    var primaryID: String = ""
    var image: String = ""
    var stars: String = ""
    var url: String = ""
    var year: String = ""
    var length: String = ""
    var rating: String = ""

}

