package com.peinanweng.firebase

import android.app.Application
import com.firebase.client.Firebase

class MovieApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        Firebase.setAndroidContext(this)

    }

}
