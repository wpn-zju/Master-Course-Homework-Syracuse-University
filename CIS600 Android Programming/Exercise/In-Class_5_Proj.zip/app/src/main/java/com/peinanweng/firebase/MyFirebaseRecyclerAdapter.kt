package com.peinanweng.firebase

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

import com.firebase.ui.database.FirebaseRecyclerAdapter
import com.firebase.ui.database.FirebaseRecyclerOptions
import com.google.firebase.database.Query

class MyFirebaseRecyclerAdapter(var modelClass: Class<Movie>, var query: Query) :
    FirebaseRecyclerAdapter<Movie, MyFirebaseRecyclerAdapter.MovieViewHolder>(
        FirebaseRecyclerOptions.Builder<Movie>()
            .setQuery(query, modelClass)
            .build()
    ) {

    var myListener: MyItemClickListener? = null

    interface MyItemClickListener {
        fun onItemClickedFromAdapter(position: Int)
        fun onItemLongClickedFromAdapter(position: Int)
    }

    fun setMyItemClickListener(listener: MyItemClickListener) {
        this.myListener = listener
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): MovieViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.movie_item, parent, false)
        return MovieViewHolder(view)
    }

    override fun onBindViewHolder(holder: MovieViewHolder, position: Int, movie: Movie) {
        holder.textViewName.text = movie.name
        holder.textViewOverView.text = movie.description
    }

    inner class MovieViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        var textViewName: TextView=view.findViewById(R.id.rvTitle)
        var textViewOverView: TextView=view.findViewById(R.id.rvOverview)

        init {
            view.setOnClickListener {
                if (myListener != null) {
                    if (adapterPosition !=
                        RecyclerView.NO_POSITION
                    ) {
                        myListener!!.onItemClickedFromAdapter(adapterPosition)
                    }
                }
            }
            view.setOnLongClickListener {
                if (myListener != null) {
                    if (adapterPosition !=
                        RecyclerView.NO_POSITION
                    ) {
                        myListener!!.onItemLongClickedFromAdapter(adapterPosition)
                    }
                }
                true
            }
        }
    }
}
