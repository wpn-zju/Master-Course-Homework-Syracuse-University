package com.peinanweng.firebase

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.firebase.client.Firebase

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        Firebase.setAndroidContext(this)

        val manager=supportFragmentManager
        val transaction=manager.beginTransaction()
        transaction.replace(R.id.fg,MovieChoiceFragment()).addToBackStack(null).commit()
    }
}
