package com.peinanweng.firebase

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import kotlinx.android.synthetic.main.fragment_movie_detail.*

private const val ARG_MOV = "idx"

class MovieDetailFragment : Fragment() {
    var movieIndex: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            movieIndex = it.getInt(ARG_MOV)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_movie_detail, container, false)
    }

    override fun onStart() {
        var args: Bundle? = getArguments()
        if (args != null) {
            movieIndex = args.getInt("index")
        } else {
            movieIndex = 0
        }
        super.onStart()
        loadMovieInfo()
    }

    private fun loadMovieInfo() {
        movieTitle.text = MovieInit().movieList[movieIndex].title
        movieID.text = MovieInit().movieList[movieIndex].id.toString()
        movieRate.text = MovieInit().movieList[movieIndex].vote_average.toString()
        movieInfo.text = MovieInit().movieList[movieIndex].overview
        moviePop.text = MovieInit().movieList[movieIndex].popularity.toString()
        movieImage.setImageResource(MovieInit().movieList[movieIndex].poster_pos!!)
    }

    companion object {
        @JvmStatic
        fun newInstance(
            param: Int
        ) = MovieDetailFragment().apply {
            arguments = Bundle().apply {
                putInt(ARG_MOV, param)
            }
        }
    }

}
