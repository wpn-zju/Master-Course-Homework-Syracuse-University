package com.peinanweng.firebase

import com.google.gson.Gson
import com.google.gson.annotations.SerializedName
import java.io.Serializable

class MovieInit{
        val movieList: List<MovieList> = Gson().fromJson(movies, Array<MovieList>::class.java).asList()
        val posterTable: MutableMap<String, Int> = mutableMapOf()
        init{
                posterTable["Dilwale Dulhania Le"] = R.drawable.dilwale
                posterTable["Your Name."] = R.drawable.your
                posterTable["Fight Club"] = R.drawable.fight
                posterTable["The Godfather"] = R.drawable.godfather
                posterTable["The Green Mile"] = R.drawable.green
                posterTable["Life Is Beautiful"] = R.drawable.life
                posterTable["On My Skin"] = R.drawable.on
                posterTable["Schindler's List"] = R.drawable.schindler
                posterTable["The Shawshank"] = R.drawable.shawshank
                posterTable["Spirited Away"] = R.drawable.spirited
                for(movie in movieList){
                        movie.poster_pos = posterTable[movie.title]
                }
        }
}

data class MovieList (
        @SerializedName("index") val index: Int?,
        @SerializedName("check") var check: Boolean?,
        @SerializedName("count") var count: Int?,
        @SerializedName("date") var date: Int?,
        @SerializedName("vote_count") val vote_count: Int?,
        @SerializedName("id") val id: Int?,
        @SerializedName("video") val video: Boolean?,
        @SerializedName("vote_average") val vote_average: Double?,
        @SerializedName("title") val title: String?,
        @SerializedName("popularity") val popularity: Double?,
        @SerializedName("poster_path") val poster_path: String?,
        @SerializedName("original_language") val original_language: String?,
        @SerializedName("original_title") val original_title: String?,
        @SerializedName("genre_ids") val genre_ids: List<Int?>?,
        @SerializedName("backdrop_path") val backdrop_path: String?,
        @SerializedName("overview")val overview: String?,
        @SerializedName("release_date") val release_date: String?,
        @SerializedName("poster_pos") var poster_pos: Int?
): Serializable

val movies = """
                [
                {
                    "index":0,
                    "check":false,
                    "count":1,
                    "date":1995,
                    "vote_count": 1880,
                    "id": 19404,
                    "video": false,
                    "vote_average": 9.2,
                    "title": "Dilwale Dulhania Le",
                    "popularity": 19.765,
                    "poster_path": "/uC6TTUhPpQCmgldGyYveKRAu8JN.jpg",
                    "original_language": "hi",
                    "original_title": "दिलवाले दुल्हनिया ले जायेंगे",
                    "genre_ids": [
                    35,
                    18,
                    10749
                    ],
                    "backdrop_path": "/nl79FQ8xWZkhL3rDr1v2RFFR6J0.jpg",
                    "adult": false,
                    "overview": "Raj is a rich, carefree, happy-go-lucky second generation NRI. Simran is the daughter of Chaudhary Baldev Singh, who in spite of being an NRI is very strict about adherence to Indian values. Simran has left for India to be married to her childhood fiancé. Raj leaves for India with a mission at his hands, to claim his lady love under the noses of her whole family. Thus begins a saga.",
                    "release_date": "1995-10-20"
                },
                {
                    "index":1,
                    "check":false,
                    "count":1,
                    "date":1994,
                    "vote_count": 10992,
                    "id": 278,
                    "video": false,
                    "vote_average": 8.6,
                    "title": "The Shawshank",
                    "popularity": 33.003,
                    "poster_path": "/9O7gLzmreU0nGkIB6K3BsJbzvNv.jpg",
                    "original_language": "en",
                    "original_title": "The Shawshank",
                    "genre_ids": [
                    18,
                    80
                    ],
                    "backdrop_path": "/j9XKiZrVeViAixVRzCta7h1VU9W.jpg",
                    "adult": false,
                    "overview": "Framed in the 1940s for the double murder of his wife and her lover, upstanding banker Andy Dufresne begins a new life at the Shawshank prison, where he puts his accounting skills to work for an amoral warden. During his long stretch in prison, Dufresne comes to be admired by the other inmates -- including an older prisoner named Red -- for his integrity and unquenchable sense of hope.",
                    "release_date": "1994-09-23"
                },
                {
                    "index":2,
                    "check":false,
                    "count":1,
                    "date":1972,
                    "vote_count": 8418,
                    "id": 238,
                    "video": false,
                    "vote_average": 8.6,
                    "title": "The Godfather",
                    "popularity": 31.863,
                    "poster_path": "/rPdtLWNsZmAtoZl9PK7S2wE3qiS.jpg",
                    "original_language": "en",
                    "original_title": "The Godfather",
                    "genre_ids": [
                    18,
                    80
                    ],
                    "backdrop_path": "/6xKCYgH16UuwEGAyroLU6p8HLIn.jpg",
                    "adult": false,
                    "overview": "Spanning the years 1945 to 1955, a chronicle of the fictional Italian-American Corleone crime family. When organized crime family patriarch, Vito Corleone barely survives an attempt on his life, his youngest son, Michael steps in to take care of the would-be killers, launching a campaign of bloody revenge.",
                    "release_date": "1972-03-14"
                },
                {
                    "index":3,
                    "check":false,
                    "count":1,
                    "date":2016,
                    "vote_count": 2884,
                    "id": 372058,
                    "video": false,
                    "vote_average": 8.5,
                    "title": "Your Name.",
                    "popularity": 26.202,
                    "poster_path": "/xq1Ugd62d23K2knRUx6xxuALTZB.jpg",
                    "original_language": "ja",
                    "original_title": "君の名は。",
                    "genre_ids": [
                    10749,
                    16,
                    18
                    ],
                    "backdrop_path": "/6vkhRvsRvWpmaRVyCXaxTkIEb7j.jpg",
                    "adult": false,
                    "overview": "High schoolers Mitsuha and Taki are complete strangers living separate lives. But one night, they suddenly switch places. Mitsuha wakes up in Taki’s body, and he in hers. This bizarre occurrence continues to happen randomly, and the two must adjust their lives around each other.",
                    "release_date": "2016-08-26"
                },
                {
                    "index":4,
                    "check":false,
                    "count":1,
                    "date":1993,
                    "vote_count": 6421,
                    "id": 424,
                    "video": false,
                    "vote_average": 8.5,
                    "title": "Schindler's List",
                    "popularity": 29.519,
                    "poster_path": "/yPisjyLweCl1tbgwgtzBCNCBle.jpg",
                    "original_language": "en",
                    "original_title": "Schindler's List",
                    "genre_ids": [
                    18,
                    36,
                    10752
                    ],
                    "backdrop_path": "/cTNYRUTXkBgPH3wP3kmPUB5U6dA.jpg",
                    "adult": false,
                    "overview": "The true story of how businessman Oskar Schindler saved over a thousand Jewish lives from the Nazis while they worked as slaves in his factory during World War II.",
                    "release_date": "1993-12-15"
                },
                {
                    "index":5,
                    "check":false,
                    "count":1,
                    "date":2001,
                    "vote_count": 5950,
                    "id": 129,
                    "video": false,
                    "vote_average": 8.5,
                    "title": "Spirited Away",
                    "popularity": 38.264,
                    "poster_path": "/dL11DBPcRhWWnJcFXl9A07MrqTI.jpg",
                    "original_language": "ja",
                    "original_title": "千と千尋の神隠し",
                    "genre_ids": [
                    16,
                    10751,
                    14
                    ],
                    "backdrop_path": "/djgM2d3e42p9GFQObg6lwK2SVw2.jpg",
                    "adult": false,
                    "overview": "A young girl, Chihiro, becomes trapped in a strange new world of spirits. When her parents undergo a mysterious transformation, she must call upon the courage she never knew she had to free her family.",
                    "release_date": "2001-07-20"
                },
                {
                    "index":6,
                    "check":false,
                    "count":1,
                    "date":1999,
                    "vote_count": 6463,
                    "id": 497,
                    "video": false,
                    "vote_average": 8.4,
                    "title": "The Green Mile",
                    "popularity": 31.653,
                    "poster_path": "/sOHqdY1RnSn6kcfAHKu28jvTebE.jpg",
                    "original_language": "en",
                    "original_title": "The Green Mile",
                    "genre_ids": [
                    14,
                    18,
                    80
                    ],
                    "backdrop_path": "/Rlt20sEbOQKPVjia7lUilFm49W.jpg",
                    "adult": false,
                    "overview": "A supernatural tale set on death row in a Southern prison, where gentle giant John Coffey possesses the mysterious power to heal people's ailments. When the cell block's head guard, Paul Edgecomb, recognizes Coffey's miraculous gift, he tries desperately to help stave off the condemned man's execution.",
                    "release_date": "1999-12-10"
                },
                {
                    "index":7,
                    "check":false,
                    "count":1,
                    "date":1997,
                    "vote_count": 5822,
                    "id": 637,
                    "video": false,
                    "vote_average": 8.4,
                    "title": "Life Is Beautiful",
                    "popularity": 23.829,
                    "poster_path": "/f7DImXDebOs148U4uPjI61iDvaK.jpg",
                    "original_language": "it",
                    "original_title": "La vita è bella",
                    "genre_ids": [
                    35,
                    18
                    ],
                    "backdrop_path": "/bORe0eI72D874TMawOOFvqWS6Xe.jpg",
                    "adult": false,
                    "overview": "A touching story of an Italian book seller of Jewish ancestry who lives in his own little fairy tale. His creative and happy life would come to an abrupt halt when his entire family is deported to a concentration camp during World War II. While locked up he tries to convince his son that the whole thing is just a game.",
                    "release_date": "1997-12-20"
                },
                {
                    "index":8,
                    "check":false,
                    "count":1,
                    "date":2018,
                    "vote_count": 348,
                    "id": 538362,
                    "video": false,
                    "vote_average": 8.4,
                    "title": "On My Skin",
                    "popularity": 34.777,
                    "poster_path": "/jv5Z9UXYGTdNDec63sAGToHSS1s.jpg",
                    "original_language": "it",
                    "original_title": "Sulla mia pelle",
                    "genre_ids": [
                    18
                    ],
                    "backdrop_path": "/lpuehRS74pgVYIQ6ZQ2fIAaoAvo.jpg",
                    "adult": false,
                    "overview": "The incredible true story behind the most controversial Italian court cases in recent years. Stefano Cucchi was arrested for a minor crime and mysteriously found dead during his detention. In one week's time, a family is changed forever.",
                    "release_date": "2018-09-12"
                },
                {
                    "index":9,
                    "check":false,
                    "count":1,
                    "date":1999,
                    "vote_count": 13651,
                    "id": 550,
                    "video": false,
                    "vote_average": 8.4,
                    "title": "Fight Club",
                    "popularity": 38.513,
                    "poster_path": "/adw6Lq9FiC9zjYEpOqfq03ituwp.jpg",
                    "original_language": "en",
                    "original_title": "Fight Club",
                    "genre_ids": [
                    18
                    ],
                    "backdrop_path": "/87hTDiay2N2qWyX4Ds7ybXi9h8I.jpg",
                    "adult": false,
                    "overview": "A ticking-time-bomb insomniac and a slippery soap salesman channel primal male aggression into a shocking new form of therapy. Their concept catches on, with underground \"fight clubs\" forming in every town, until an eccentric gets in the way and ignites an out-of-control spiral toward oblivion.",
                    "release_date": "1999-10-15"
                }
        ]
        """.trimIndent()

val movieSorted = """
                [
                {
                    "index":0,
                    "check":false,
                    "count":1,
                    "date":2018,
                    "vote_count": 348,
                    "id": 538362,
                    "video": false,
                    "vote_average": 8.4,
                    "title": "On My Skin",
                    "popularity": 34.777,
                    "poster_path": "/jv5Z9UXYGTdNDec63sAGToHSS1s.jpg",
                    "original_language": "it",
                    "original_title": "Sulla mia pelle",
                    "genre_ids": [
                    18
                    ],
                    "backdrop_path": "/lpuehRS74pgVYIQ6ZQ2fIAaoAvo.jpg",
                    "adult": false,
                    "overview": "The incredible true story behind the most controversial Italian court cases in recent years. Stefano Cucchi was arrested for a minor crime and mysteriously found dead during his detention. In one week's time, a family is changed forever.",
                    "release_date": "2018-09-12"
                },
                {
                    "index":1,
                    "check":false,
                    "count":1,
                    "date":2016,
                    "vote_count": 2884,
                    "id": 372058,
                    "video": false,
                    "vote_average": 8.5,
                    "title": "Your Name.",
                    "popularity": 26.202,
                    "poster_path": "/xq1Ugd62d23K2knRUx6xxuALTZB.jpg",
                    "original_language": "ja",
                    "original_title": "君の名は。",
                    "genre_ids": [
                    10749,
                    16,
                    18
                    ],
                    "backdrop_path": "/6vkhRvsRvWpmaRVyCXaxTkIEb7j.jpg",
                    "adult": false,
                    "overview": "High schoolers Mitsuha and Taki are complete strangers living separate lives. But one night, they suddenly switch places. Mitsuha wakes up in Taki’s body, and he in hers. This bizarre occurrence continues to happen randomly, and the two must adjust their lives around each other.",
                    "release_date": "2016-08-26"
                },

                {
                    "index":2,
                    "check":false,
                    "count":1,
                    "date":2001,
                    "vote_count": 5950,
                    "id": 129,
                    "video": false,
                    "vote_average": 8.5,
                    "title": "Spirited Away",
                    "popularity": 38.264,
                    "poster_path": "/dL11DBPcRhWWnJcFXl9A07MrqTI.jpg",
                    "original_language": "ja",
                    "original_title": "千と千尋の神隠し",
                    "genre_ids": [
                    16,
                    10751,
                    14
                    ],
                    "backdrop_path": "/djgM2d3e42p9GFQObg6lwK2SVw2.jpg",
                    "adult": false,
                    "overview": "A young girl, Chihiro, becomes trapped in a strange new world of spirits. When her parents undergo a mysterious transformation, she must call upon the courage she never knew she had to free her family.",
                    "release_date": "2001-07-20"
                },
                {
                    "index":3,
                    "check":false,
                    "count":1,
                    "date":1999,
                    "vote_count": 6463,
                    "id": 497,
                    "video": false,
                    "vote_average": 8.4,
                    "title": "The Green Mile",
                    "popularity": 31.653,
                    "poster_path": "/sOHqdY1RnSn6kcfAHKu28jvTebE.jpg",
                    "original_language": "en",
                    "original_title": "The Green Mile",
                    "genre_ids": [
                    14,
                    18,
                    80
                    ],
                    "backdrop_path": "/Rlt20sEbOQKPVjia7lUilFm49W.jpg",
                    "adult": false,
                    "overview": "A supernatural tale set on death row in a Southern prison, where gentle giant John Coffey possesses the mysterious power to heal people's ailments. When the cell block's head guard, Paul Edgecomb, recognizes Coffey's miraculous gift, he tries desperately to help stave off the condemned man's execution.",
                    "release_date": "1999-12-10"
                },
                {
                    "index":4,
                    "check":false,
                    "count":1,
                    "date":1999,
                    "vote_count": 13651,
                    "id": 550,
                    "video": false,
                    "vote_average": 8.4,
                    "title": "Fight Club",
                    "popularity": 38.513,
                    "poster_path": "/adw6Lq9FiC9zjYEpOqfq03ituwp.jpg",
                    "original_language": "en",
                    "original_title": "Fight Club",
                    "genre_ids": [
                    18
                    ],
                    "backdrop_path": "/87hTDiay2N2qWyX4Ds7ybXi9h8I.jpg",
                    "adult": false,
                    "overview": "A ticking-time-bomb insomniac and a slippery soap salesman channel primal male aggression into a shocking new form of therapy. Their concept catches on, with underground \"fight clubs\" forming in every town, until an eccentric gets in the way and ignites an out-of-control spiral toward oblivion.",
                    "release_date": "1999-10-15"
                },

                {
                    "index":5,
                    "check":false,
                    "count":1,
                    "date":1997,
                    "vote_count": 5822,
                    "id": 637,
                    "video": false,
                    "vote_average": 8.4,
                    "title": "Life Is Beautiful",
                    "popularity": 23.829,
                    "poster_path": "/f7DImXDebOs148U4uPjI61iDvaK.jpg",
                    "original_language": "it",
                    "original_title": "La vita è bella",
                    "genre_ids": [
                    35,
                    18
                    ],
                    "backdrop_path": "/bORe0eI72D874TMawOOFvqWS6Xe.jpg",
                    "adult": false,
                    "overview": "A touching story of an Italian book seller of Jewish ancestry who lives in his own little fairy tale. His creative and happy life would come to an abrupt halt when his entire family is deported to a concentration camp during World War II. While locked up he tries to convince his son that the whole thing is just a game.",
                    "release_date": "1997-12-20"
                },
                {
                    "index":6,
                    "check":false,
                    "count":1,
                    "date":1995,
                    "vote_count": 1880,
                    "id": 19404,
                    "video": false,
                    "vote_average": 9.2,
                    "title": "Dilwale Dulhania Le",
                    "popularity": 19.765,
                    "poster_path": "/uC6TTUhPpQCmgldGyYveKRAu8JN.jpg",
                    "original_language": "hi",
                    "original_title": "दिलवाले दुल्हनिया ले जायेंगे",
                    "genre_ids": [
                    35,
                    18,
                    10749
                    ],
                    "backdrop_path": "/nl79FQ8xWZkhL3rDr1v2RFFR6J0.jpg",
                    "adult": false,
                    "overview": "Raj is a rich, carefree, happy-go-lucky second generation NRI. Simran is the daughter of Chaudhary Baldev Singh, who in spite of being an NRI is very strict about adherence to Indian values. Simran has left for India to be married to her childhood fiancé. Raj leaves for India with a mission at his hands, to claim his lady love under the noses of her whole family. Thus begins a saga.",
                    "release_date": "1995-10-20"
                },
                {
                    "index":7,
                    "check":false,
                    "count":1,
                    "date":1994,
                    "vote_count": 10992,
                    "id": 278,
                    "video": false,
                    "vote_average": 8.6,
                    "title": "The Shawshank",
                    "popularity": 33.003,
                    "poster_path": "/9O7gLzmreU0nGkIB6K3BsJbzvNv.jpg",
                    "original_language": "en",
                    "original_title": "The Shawshank",
                    "genre_ids": [
                    18,
                    80
                    ],
                    "backdrop_path": "/j9XKiZrVeViAixVRzCta7h1VU9W.jpg",
                    "adult": false,
                    "overview": "Framed in the 1940s for the double murder of his wife and her lover, upstanding banker Andy Dufresne begins a new life at the Shawshank prison, where he puts his accounting skills to work for an amoral warden. During his long stretch in prison, Dufresne comes to be admired by the other inmates -- including an older prisoner named Red -- for his integrity and unquenchable sense of hope.",
                    "release_date": "1994-09-23"
                },
                {
                    "index":8,
                    "check":false,
                    "count":1,
                    "date":1993,
                    "vote_count": 6421,
                    "id": 424,
                    "video": false,
                    "vote_average": 8.5,
                    "title": "Schindler's List",
                    "popularity": 29.519,
                    "poster_path": "/yPisjyLweCl1tbgwgtzBCNCBle.jpg",
                    "original_language": "en",
                    "original_title": "Schindler's List",
                    "genre_ids": [
                    18,
                    36,
                    10752
                    ],
                    "backdrop_path": "/cTNYRUTXkBgPH3wP3kmPUB5U6dA.jpg",
                    "adult": false,
                    "overview": "The true story of how businessman Oskar Schindler saved over a thousand Jewish lives from the Nazis while they worked as slaves in his factory during World War II.",
                    "release_date": "1993-12-15"
                },
                {
                    "index":9,
                    "check":false,
                    "count":1,
                    "date":1972,
                    "vote_count": 8418,
                    "id": 238,
                    "video": false,
                    "vote_average": 8.6,
                    "title": "The Godfather",
                    "popularity": 31.863,
                    "poster_path": "/rPdtLWNsZmAtoZl9PK7S2wE3qiS.jpg",
                    "original_language": "en",
                    "original_title": "The Godfather",
                    "genre_ids": [
                    18,
                    80
                    ],
                    "backdrop_path": "/6xKCYgH16UuwEGAyroLU6p8HLIn.jpg",
                    "adult": false,
                    "overview": "Spanning the years 1945 to 1955, a chronicle of the fictional Italian-American Corleone crime family. When organized crime family patriarch, Vito Corleone barely survives an attempt on his life, his youngest son, Michael steps in to take care of the would-be killers, launching a campaign of bloody revenge.",
                    "release_date": "1972-03-14"
                }
        ]
        """.trimIndent()