package com.peinanweng.firebase

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.firebase.database.FirebaseDatabase
import kotlinx.android.synthetic.main.fragment_movie_choice.*

var query = FirebaseDatabase.getInstance()
    .reference
    .child("moviedata")
    .limitToLast(50)

class MovieChoiceFragment : Fragment(),MyFirebaseRecyclerAdapter.MyItemClickListener {

    var idx: Int = 0
    private val movie: ArrayList<Movie>? = null
    lateinit var myAdapter:RecyclerViewAdapter
    lateinit var myAdapter2:MyFirebaseRecyclerAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        retainInstance = true
        if (savedInstanceState != null) {
            idx = savedInstanceState.getInt("index")
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_movie_choice, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val layoutManager = LinearLayoutManager(view.context)
        rv.hasFixedSize()
        rv.layoutManager = layoutManager
        //myAdapter = RecyclerViewAdapter(ArrayList(MovieInit().movieList))
        //myAdapter.setMyItemClickListener(this)
        myAdapter2 = MyFirebaseRecyclerAdapter(Movie::class.java,query)
        myAdapter2.setMyItemClickListener(this)
        rv.adapter = myAdapter2
    }

    override fun onStart() {
        super.onStart()
        myAdapter2.startListening()
    }

    override fun onStop() {
        super.onStop()
        myAdapter2.stopListening()
    }

    override fun onItemClickedFromAdapter(position: Int) {
        idx = position
        var movieDetailFragment = MovieDetailFragment()
        val bundle = Bundle()
        bundle.putInt("index", idx)
        movieDetailFragment.setArguments(bundle)
        val manager = activity?.supportFragmentManager
        val transaction = manager?.beginTransaction()
        transaction?.replace(R.id.fg, movieDetailFragment)
        transaction?.addToBackStack(null)
        transaction?.commit()
    }

    override fun onItemLongClickedFromAdapter(position: Int) {
        Toast.makeText(activity, "You Click the $position movie!",Toast.LENGTH_SHORT).show()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("index", idx)
    }
}