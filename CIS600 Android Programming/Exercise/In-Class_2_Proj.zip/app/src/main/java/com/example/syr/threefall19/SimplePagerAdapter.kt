package com.example.syr.threefall19

import android.util.Log

class SimplePagerAdapter(fragmentManager: androidx.fragment.app.FragmentManager) : androidx.fragment.app.FragmentStatePagerAdapter(fragmentManager) {
    override fun getItem(p0: Int): androidx.fragment.app.Fragment? {
        Log.i("SimplePagerAdapter", "item index $p0" )
        return when (p0) {
            0 -> FirstFragment()
            1 -> SecondFragment()
            2 -> ThirdFragment()
            else -> null
        }
    }

    override fun getCount(): Int {
        return 3
    }
}