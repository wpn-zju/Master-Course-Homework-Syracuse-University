package com.example.syr.threefall19

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.TextView
import kotlinx.android.synthetic.main.activity_text_tab_vp.*


class TextTabViewPagerActivity : AppCompatActivity(), View.OnClickListener {

    private lateinit var vp: androidx.viewpager.widget.ViewPager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_text_tab_vp)


        setSupportActionBar(myToolbar5)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        // View Pager
        vp = findViewById(R.id.viewP2)
        vp.adapter = SimplePagerAdapter(supportFragmentManager)
        vp.currentItem = 0

        txtFirst.setOnClickListener(this)
        // Use tag to indicate Text View's position in linear layout
        txtFirst.tag = 0
        txtFirst.isSelected = true
        txtSecond.setOnClickListener(this)
        txtSecond.tag = 1
        txtThird.setOnClickListener(this)
        txtThird.tag = 2

        vp.addOnPageChangeListener(object : androidx.viewpager.widget.ViewPager.OnPageChangeListener{
            override fun onPageScrollStateChanged(p0: Int) {
//                ("not implemented") //To change body of created functions use File | Settings | File Templates.
            }

            override fun onPageScrolled(p0: Int, p1: Float, p2: Int) {
//                ("not implemented") //To change body of created functions use File | Settings | File Templates.
            }

            override fun onPageSelected(p0: Int) {
                var i = 0
                while (i < 3) {
                    txtPanel.findViewWithTag<TextView>(i).isSelected = p0 == i
                    ++i
                }
            }
        })

        // PageTransformer that will modify each page's animation properties
        vp.setPageTransformer(false) { p0, p1 ->
            val norm = Math.abs(Math.abs(p1) - 1)
            p0.scaleX = norm/2 + 0.5f
            p0.scaleY = norm/2 + 0.5f
        }
    }

    override fun onClick(v: View?) { // v is the Text View
        val tag: Int = v?.tag.toString().toInt() // v?.tag was set to indicate the position of the text view in linear layout
        var i = 0

        while (i < 3){
            // Highlight the clicked Text View
            txtPanel.findViewWithTag<TextView>(i).isSelected = tag == i
            i++
        }
        // Set the currentItem index of View Pager to tag
        vp.currentItem = tag
    }

}
