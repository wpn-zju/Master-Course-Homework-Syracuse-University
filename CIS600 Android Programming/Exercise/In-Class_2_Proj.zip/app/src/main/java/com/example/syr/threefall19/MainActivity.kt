package com.example.syr.threefall19

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import com.google.android.material.snackbar.Snackbar
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Theme.AppCompat.Light.NoActionBar -> Prevent native action bar, check Manifest
        // Set toolbar as support action bar
        setSupportActionBar(myToolbar)

        // Get support action bar
        val appBar = supportActionBar

        // set App Title
        appBar!!.title = "Android Three"

        // set sub title
        appBar.subtitle = "Activities and Fragments"

        // Display app icon in toolbar
        appBar.setDisplayShowHomeEnabled(true)
        appBar.setLogo(R.mipmap.ic_launcher)
        appBar.setDisplayUseLogoEnabled(true)

        // set listener to AboutMeFragment button
        aboutMe.setOnClickListener{
            val fragment: androidx.fragment.app.Fragment? = supportFragmentManager.findFragmentById(R.id.meContainer)
            if (fragment == null) {
                supportFragmentManager.beginTransaction().add(R.id.meContainer, BlankFragment()).commit()
                aboutMe.text = "Remove Fragment"
            } else {
                supportFragmentManager.beginTransaction().remove(fragment).commit()
                aboutMe.text = "About Me"
            }
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        // inflate the menu into toolbar
        val inflater = menuInflater
        inflater.inflate(R.menu.menu_toolbar, menu)

        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        /* handle selected (pressed) toolbar menu items */
        when (item?.itemId) {
            R.id.action_favorite -> {
                Toast.makeText(this, "Favorite Action Item Selected", Toast.LENGTH_LONG).show()
                return true
            }
            R.id.action_settings -> {
                Snackbar.make(meContainer, "Settings Action Item Selected", Snackbar.LENGTH_SHORT).show()
                return true
            }
            R.id.action_act1 -> { // Simple Fragments
                val intent = Intent(this, FirstActivity::class.java)

                startActivity(intent)
            }
            R.id.action_act2 -> { // Simple MasterFragment/Detail
                val intent = Intent(this, SimpleMasterDetailActivity::class.java)

                startActivity(intent)
            }
            R.id.action_act3 -> { // ViewPager with Button
                val intent = Intent(this, ButtonViewPagerActivity::class.java)

                startActivity(intent)
            }
            R.id.action_act4 -> { // ViewPager with Tab
                val intent = Intent(this, TextTabViewPagerActivity::class.java)

                startActivity(intent)
            }
        }
        return super.onOptionsItemSelected(item)
    }
}
