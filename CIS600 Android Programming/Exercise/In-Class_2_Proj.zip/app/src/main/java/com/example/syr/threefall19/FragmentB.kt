package com.example.syr.threefall19

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import kotlinx.android.synthetic.main.fragment_b.*
import android.util.Log


private const val ARG_PARAM = "param"


class FragmentB : androidx.fragment.app.Fragment() {
    private var mParam: String? = null

    private var mListener: OnFragmentInteractionListener? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            mParam = it.getString(ARG_PARAM)
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        //after inflating layout!! do anything on UI, frgMessage being TextView ID
        frgMessage.text = mParam.toString()
        btnReplace.setOnClickListener{
            onButtonPressed(it)
        }

    }
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_b, container, false)
    }

    fun onButtonPressed(uri: View) {
        if (mListener != null) {
            mListener?.onFragmentInteraction(uri)
        }
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        if (context is OnFragmentInteractionListener) {
            mListener = context
            Log.i("onAttach: ", "context = $context")
        } else {
            throw RuntimeException("$context must implement OnFragmentInteractionListener")
        }
    }

    override fun onDetach() {
        super.onDetach()
        mListener = null
    }


    interface OnFragmentInteractionListener {
        fun onFragmentInteraction(uri: View)
    }

    companion object {
        @JvmStatic
        fun newInstance(p: String) =
                FragmentB().apply {
                    arguments = Bundle().apply {
                        putString(ARG_PARAM, p)
                    }
                }
    }
}
