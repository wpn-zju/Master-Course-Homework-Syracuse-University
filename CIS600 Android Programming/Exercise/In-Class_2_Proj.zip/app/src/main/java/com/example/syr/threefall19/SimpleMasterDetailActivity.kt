package com.example.syr.threefall19

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import kotlinx.android.synthetic.main.activity_simple_master_detail.*

class SimpleMasterDetailActivity : AppCompatActivity(), MasterFragment.OnMasterDetailListener {

    private var mTwoPane = false // check tablet or phone

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_simple_master_detail)


        setSupportActionBar(myToolbar3)

        val y = resources.configuration.screenHeightDp
        val x = resources.configuration.screenWidthDp

        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        if (savedInstanceState == null){
            supportFragmentManager.beginTransaction().replace(R.id.mContainer, MasterFragment()).commit()
        }

        if (findViewById<FrameLayout>(R.id.dContainer) != null){
            mTwoPane = true // Tablet layout is loaded
        }
    }

    override fun onBookSelect(v: View) { // v is button on Master page
        val title = findViewById<Button>(v.id).text.toString()
        val fragment = DetailFragment.newInstance(title)

        if (mTwoPane) {
            supportFragmentManager.beginTransaction().replace(R.id.dContainer, fragment).addToBackStack(null).commit()
        } else {
            supportFragmentManager.beginTransaction().replace(R.id.mContainer, fragment).addToBackStack(null).commit()
        }
    }

}
