package com.example.syr.threefall19

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_view_pager.*

class ButtonViewPagerActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_view_pager)

        setSupportActionBar(myToolbar4)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        // View Pager
        viewP.adapter = SimplePagerAdapter(supportFragmentManager)
        viewP.currentItem = 0

        btnFirst.setOnClickListener {
            viewP.currentItem = 0
        }
        btnSecond.setOnClickListener {
            viewP.currentItem = 1
        }
        btnThird.setOnClickListener {
            viewP.currentItem = 2
        }
        viewP.setPageTransformer(false, MyPageTransformer())
    }

    // PageTransformer that will modify each page's animation properties such as alpha, translation and scale
    private class MyPageTransformer: androidx.viewpager.widget.ViewPager.PageTransformer {
        private val MIN_SCALE = 0.85F
        private val MIN_ALPHA = 0.5F

        override fun transformPage(p0: View, p1: Float) {
            val pageW = p0.width
            val pageH = p0.height

            if (p1 < -1) { // way off-screen to the left!
                p0.alpha = 0f
            }
            else if (p1 <= 1) { //[-1 1]
                val scaleFactor = Math.max(MIN_SCALE, 1 -Math.abs(p1))
                val verMargin = pageH * (1-scaleFactor)/2
                val horMargin = pageW * (1-scaleFactor)/2

                if (p1 < 0)
                    p0.translationX = horMargin - verMargin/2
                else
                    p0.translationX = verMargin/2 - horMargin

                p0.scaleX = scaleFactor
                p0.scaleY = scaleFactor

                p0.alpha = MIN_ALPHA + (scaleFactor - MIN_SCALE)/(1 - MIN_SCALE)*(1 - MIN_ALPHA)
                // Uncomment out the following line. Observe and describe
                // the difference when you bring the pages onto the screen via swipe gesture
                // p0.rotationY = p0.translationX*(-30)
            }
            else { // (1, +infinity
                p0.alpha = 0F
            }
        }
    }
}
