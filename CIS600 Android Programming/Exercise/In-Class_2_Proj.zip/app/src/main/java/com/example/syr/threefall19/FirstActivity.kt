package com.example.syr.threefall19

import android.app.Activity
import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import com.example.syr.threefall19.FragmentB.OnFragmentInteractionListener
import kotlinx.android.synthetic.main.activity_first.*

class FirstActivity : AppCompatActivity(), OnFragmentInteractionListener {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_first)

        setSupportActionBar(myToolbar2)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        // load FragmentB dynamically
        val fragment = FragmentB.newInstance("Fragment B is Created")
        val transaction = supportFragmentManager.beginTransaction()
        transaction.add(R.id.simpleContainer2, fragment)
        transaction.addToBackStack(null) // empty fragment container to back stack
        transaction.commit()
    }

    override fun onFragmentInteraction(uri: View) {
        val transaction = supportFragmentManager.beginTransaction()
        // Replace Fragment B with Fragment C
        transaction.replace(R.id.simpleContainer2, FragmentC())
        //transaction.addToBackStack(null) // fragment B pushed into back stack
        transaction.commit()
    }

}

// Ignore below, it is Demo class, not used in this app
class MyActivity : Activity() {
    //
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_DPAD_CENTER) {
            // When the user center presses , let them pick a contact.
            startActivityForResult( Intent(Intent.ACTION_PICK ,
                    Uri.parse("content://contacts")), PICK_CONTACT_REQUEST )
            return true
        }
        return false
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, intent: Intent?) {
        when (requestCode) {
            PICK_CONTACT_REQUEST -> if (resultCode == RESULT_OK) {
                startActivity(Intent(Intent.ACTION_VIEW , intent?.data))
            }
        }
    }

    companion object {
        internal val PICK_CONTACT_REQUEST = 0
    }
}

