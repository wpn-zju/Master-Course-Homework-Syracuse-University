package com.peinanweng.colormyviews

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        makeColored(findViewById<TextView>(R.id.box_one_text))
        makeColored(findViewById<TextView>(R.id.box_two_text))
        makeColored(findViewById<TextView>(R.id.box_three_text))
        makeColored(findViewById<TextView>(R.id.box_four_text))
        makeColored(findViewById<TextView>(R.id.box_five_text))

        findViewById<Button>(R.id.button_one).setOnClickListener{ findViewById<TextView>(R.id.box_three_text).setBackgroundResource(R.color.red) }
        findViewById<Button>(R.id.button_two).setOnClickListener{ findViewById<TextView>(R.id.box_four_text).setBackgroundResource(R.color.yellow) }
        findViewById<Button>(R.id.button_three).setOnClickListener{ findViewById<TextView>(R.id.box_five_text).setBackgroundResource(R.color.green) }
    }

    private fun makeColored(view: View) {
        when (view.id) {

            // Boxes using Color class colors for background
            R.id.box_three_text -> view.setBackgroundColor(Color.DKGRAY)
            R.id.box_two_text -> view.setBackgroundColor(Color.GRAY)

            // Boxes using Android color resources for background
            R.id.box_three_text -> view.setBackgroundResource(android.R.color.holo_green_light)
            R.id.box_four_text -> view.setBackgroundResource(android.R.color.holo_green_dark)
            R.id.box_five_text -> view.setBackgroundResource(android.R.color.holo_green_light)

            else -> view.setBackgroundColor(Color.LTGRAY)
        }
    }
}
