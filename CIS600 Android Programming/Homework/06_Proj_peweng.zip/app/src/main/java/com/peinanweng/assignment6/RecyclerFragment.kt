package com.peinanweng.assignment6

import android.annotation.SuppressLint
import android.content.Context
import android.os.Bundle
import android.view.*
import android.widget.PopupMenu
import android.widget.Toast
import androidx.appcompat.widget.SearchView
import androidx.appcompat.widget.Toolbar
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.peinanweng.assignment6.databinding.FragmentRecyclerBinding
import kotlinx.android.synthetic.main.layout_toolbar.*

class RecyclerFragment : Fragment(), MovieRecyclerViewAdapter.MyItemClickListener {
    private lateinit var binding: FragmentRecyclerBinding
    private lateinit var viewAdapter: MovieRecyclerViewAdapter
    private var listener: OnRecyclerInteractionListener? = null

    interface OnRecyclerInteractionListener {
        fun onItemClicked(movie: MovieData)
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        listener = context as OnRecyclerInteractionListener
    }

    override fun onResume() {
        requireActivity().toolbar.setTitle(R.string.movie_list)
        super.onResume()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        retainInstance = true
        setHasOptionsMenu(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentRecyclerBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val viewManager: RecyclerView.LayoutManager = LinearLayoutManager(activity)

        viewAdapter = MovieRecyclerViewAdapter(context!!)
        viewAdapter.setMyItemClickListener(this)

        binding.fragmentRecycler.apply {
            setHasFixedSize(true)
            layoutManager = viewManager
            adapter = viewAdapter
        }
    }

    override fun onDetach() {
        super.onDetach()
        listener = null
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        super.onCreateOptionsMenu(menu, inflater)
        if (menu.findItem(R.id.action_search) == null) {
            inflater.inflate(R.menu.menu_task2, menu)
            val search = menu.findItem(R.id.action_search)!!.actionView as SearchView
            search.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
                override fun onQueryTextSubmit(query: String): Boolean {
                    val findId = viewAdapter.findFirst(query)
                    if (findId == -1) {
                        Toast.makeText(requireActivity(), "Not Found", Toast.LENGTH_SHORT).show()
                        binding.fragmentRecycler.smoothScrollToPosition(0)
                    } else {
                        binding.fragmentRecycler.smoothScrollToPosition(findId)
                    }
                    return true
                }

                override fun onQueryTextChange(p0: String?): Boolean {
                    return true
                }
            })

            val expandListener = object : MenuItem.OnActionExpandListener {
                override fun onMenuItemActionExpand(p0: MenuItem?): Boolean {
                    return true
                }

                override fun onMenuItemActionCollapse(p0: MenuItem?): Boolean {
                    return true
                }
            }

            val actionMenuItem = menu.findItem(R.id.action_search)
            actionMenuItem.setOnActionExpandListener(expandListener)
        }
    }

    companion object {
        @JvmStatic
        fun newInstance(): RecyclerFragment {
            return RecyclerFragment()
        }
    }

    private fun onItemClickedFromRecyclerViewFragment(movie: MovieData) {
        listener?.onItemClicked(movie)
    }

    override fun onItemClickedFromAdapter(movie: MovieData) {
        onItemClickedFromRecyclerViewFragment(movie)
    }

    override fun onOverflowMenuClickedFromAdapter(view: View, position: Int) {
        val popup = PopupMenu(requireContext(), view)
        val menuInflater = popup.menuInflater
        menuInflater.inflate(R.menu.menu_task2_popup, popup.menu)

        popup.setOnMenuItemClickListener {
            when (it.itemId) {
                R.id.action_dup -> {
                    viewAdapter.addMovie(position)
                    return@setOnMenuItemClickListener true
                }
                R.id.action_rem -> {
                    viewAdapter.deleteMovie(position)
                    return@setOnMenuItemClickListener true
                }
                else -> {
                    return@setOnMenuItemClickListener false
                }
            }
        }
        popup.show()
    }
}
