package com.peinanweng.assignment6

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.squareup.picasso.Picasso
import java.util.*

@Suppress("unused")
class MovieRecyclerViewAdapter(context: Context) : RecyclerView.Adapter<MovieRecyclerViewAdapter.MovieViewHolder>() {
    var myListener: MyItemClickListener? = null
    val database = DatabaseHelper(context)
    var items: ArrayList<MovieData>

    init {
        database.initializeTables()
        items = database.getAllMovies()
    }

    interface MyItemClickListener {
        fun onItemClickedFromAdapter(movie: MovieData)
        fun onOverflowMenuClickedFromAdapter(view: View, position: Int)
    }

    fun setMyItemClickListener (listener: MyItemClickListener) {
        this.myListener = listener
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MovieViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        val view = layoutInflater.inflate(R.layout.layout_movie_card, parent, false)
        return MovieViewHolder(view)
    }

    override fun getItemCount(): Int {
        return items.size
    }

    override fun onBindViewHolder(holder: MovieViewHolder, position: Int) {
        val movie = items[position]
        holder.movieTitle.text = movie.title
        var length = movie.overview!!.length
        length = if (length > 150) 150 else length
        holder.movieOverview.text = String.format("%s ...", movie.overview.substring(0, length - 1))

        val url = "https://image.tmdb.org/t/p/w185/" + movie.poster_path!!
        Picasso.Builder(holder.itemView.context).listener {_, _, e->e.printStackTrace() }.build()
            .load(url).error(R.mipmap.ic_launcher).into(holder.moviePoster)
    }

    override fun getItemViewType(position: Int): Int {
        return if (items[position].vote_average!! >= 6) 1 else 2
    }

    fun findFirst(query: String): Int {
        for (i in items.indices) {
            if (items[i].title!!.toLowerCase(Locale.ROOT) == query.toLowerCase(Locale.ROOT)) {
                return i
            }
        }
        return -1
    }

    fun addMovie(position: Int) {
        val movie = items[position].copy()
        items.add(position + 1, movie)
        items[position + 1].title = String.format("Copy of %s", items[position].title)
        database.addMovie(movie)
        notifyItemInserted(position + 1)
    }

    fun deleteMovie(position: Int) {
        database.deleteMovie(items[position].db_id!!)
        items.removeAt(position)
        notifyItemRemoved(position)
    }

    fun getItem(position: Int): MovieData {
        return items[position]
    }

    fun sortTitle() {
        items.sortBy { it.title }
        notifyItemRangeChanged(0, items.size)
    }

    fun sortRating() {
        items.sortByDescending { it.vote_average }
        notifyItemRangeChanged(0, items.size)
    }

    inner class MovieViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val moviePoster: ImageView = view.findViewById(R.id.rvPoster)
        val movieTitle: TextView = view.findViewById(R.id.rvTitle)
        val movieOverview: TextView = view.findViewById(R.id.rvOverview)
        val movieOverflow: ImageView = view.findViewById(R.id.rvOverflow)

        init {
            movieOverflow.setOnClickListener {
                if (myListener != null && adapterPosition != RecyclerView.NO_POSITION) {
                    myListener!!.onOverflowMenuClickedFromAdapter(it, adapterPosition)
                }
            }

            view.setOnClickListener {
                if (myListener != null && adapterPosition != RecyclerView.NO_POSITION) {
                    myListener!!.onItemClickedFromAdapter(items[adapterPosition])
                }
            }
        }
    }
}
