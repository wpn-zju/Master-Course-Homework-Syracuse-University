package com.peinanweng.assignment6

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context): SQLiteOpenHelper(context, DB_NAME, null, DB_VER) {
    companion object {
        private val DB_NAME = "mymovies.db"
        private val DB_VER = 1
        private val COL_VOTE_CNT = "vote_count"
        private val COL_ID = "id"
        private val COL_VOTE_AVG = "vote_average"
        private val COL_TITLE = "title"
        private val COL_POPULARITY = "popularity"
        private val COL_POSTER = "poster_path"
        private val COL_ORG_LANG = "original_language"
        private val COL_ORG_TITLE = "original_title"
        private val COL_BACKDROP = "backdrop_path"
        private val COL_OVERVIEW = "overview"
        private val COL_RELEASE = "release_date"
        private val COL_MOVIE_ID = "movie_id"
        private val CREATE_TABLE_MOVIES =
            "CREATE TABLE IF NOT EXISTS movies ( $COL_ID INTEGER PRIMARY KEY, $COL_MOVIE_ID INTEGER, $COL_TITLE TEXT, $COL_VOTE_AVG REAL, $COL_VOTE_CNT INTEGER, $COL_POSTER TEXT, $COL_BACKDROP TEXT,$COL_POPULARITY REAL, $COL_OVERVIEW TEXT, $COL_ORG_LANG TEXT, $COL_ORG_TITLE TEXT,$COL_RELEASE TEXT )"
        private val DROP_TABLE_MOVIES = "DROP TABLE IF EXISTS movies"
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(CREATE_TABLE_MOVIES)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVer: Int, newVer: Int) {
        db.execSQL(DROP_TABLE_MOVIES)
    }

    fun initializeTables() {
        val db = this.readableDatabase
        val query = "SELECT * FROM movies";
        val c = db.rawQuery(query, null)
        if (c.count <= 0) {
            insertAllMovies()
        }
        c.close()
    }

    fun insertAllMovies() {
        val staticMovie = MovieList()
        staticMovie.movieList.forEach { addMovie(it) }
    }

    fun addMovie(movie: MovieData): Long {
        val db = this.writableDatabase
        val values = ContentValues()
        values.put(COL_MOVIE_ID, movie.id)
        values.put(COL_VOTE_AVG, movie.vote_average)
        values.put(COL_TITLE, movie.title)
        values.put(COL_ORG_TITLE, movie.original_title)
        values.put(COL_ORG_LANG, movie.original_language)
        values.put(COL_OVERVIEW, movie.overview)
        values.put(COL_POPULARITY, movie.popularity)
        values.put(COL_POSTER, movie.poster_path)
        values.put(COL_BACKDROP, movie.backdrop_path)
        values.put(COL_VOTE_CNT, movie.vote_count)
        values.put(COL_RELEASE, movie.release_date)
        return db.insert("movies", null, values)
    }

    fun getMovie(mid: Int): MovieData? {
        val query = "SELECT * FROM movies WHERE $COL_ID = $mid"
        val db = this.readableDatabase
        val c = db.rawQuery(query, null)
        if (c.moveToFirst()){
            val movie = MovieData(
                vote_count = c.getInt(c.getColumnIndex(COL_VOTE_CNT)),
                id = c.getInt(c.getColumnIndex(COL_MOVIE_ID)),
                vote_average = c.getDouble(c.getColumnIndex(COL_VOTE_AVG)),
                title = c.getString(c.getColumnIndex(COL_TITLE)),
                popularity = c.getDouble(c.getColumnIndex(COL_POPULARITY)),
                poster_path = c.getString(c.getColumnIndex(COL_POSTER)),
                original_language = c.getString(c.getColumnIndex(COL_ORG_LANG)),
                original_title =  c.getString(c.getColumnIndex(COL_ORG_TITLE)),
                backdrop_path = c.getString(c.getColumnIndex(COL_BACKDROP)),
                overview = c.getString(c.getColumnIndex(COL_OVERVIEW)),
                release_date = c.getString(c.getColumnIndex(COL_RELEASE)),
                db_id = c.getInt(c.getColumnIndex(COL_ID))
            )
            c.close()
            return movie
        } else {
            c.close()
            return null
        }
    }

    fun getAllMovies(): ArrayList<MovieData> {
        val db = this.readableDatabase
        val movies = ArrayList<MovieData>()
        val query = "SELECT * FROM movies"
        val c = db.rawQuery(query, null)
        if (c.moveToFirst()) {
            do {
                movies.add(
                    MovieData(
                        vote_count = c.getInt(c.getColumnIndex(COL_VOTE_CNT)),
                        id = c.getInt(c.getColumnIndex(COL_MOVIE_ID)),
                        vote_average = c.getDouble(c.getColumnIndex(COL_VOTE_AVG)),
                        title = c.getString(c.getColumnIndex(COL_TITLE)),
                        popularity = c.getDouble(c.getColumnIndex(COL_POPULARITY)),
                        poster_path = c.getString(c.getColumnIndex(COL_POSTER)),
                        original_language = c.getString(c.getColumnIndex(COL_ORG_LANG)),
                        original_title = c.getString(c.getColumnIndex(COL_ORG_TITLE)),
                        backdrop_path = c.getString(c.getColumnIndex(COL_BACKDROP)),
                        overview = c.getString(c.getColumnIndex(COL_OVERVIEW)),
                        release_date = c.getString(c.getColumnIndex(COL_RELEASE)),
                        db_id = c.getInt(c.getColumnIndex(COL_ID))
                    ))
            } while (c.moveToNext())
        }
        c.close()
        return movies
    }

    fun deleteMovie(id: Int) {
        val db = this.writableDatabase
        db.delete("movies", "$COL_ID = ?", arrayOf(id.toString()))
    }

    fun updateMovie(movie: MovieData): Int {
        val db = this.writableDatabase
        val values = ContentValues()
        values.put(COL_MOVIE_ID, movie.id)
        values.put(COL_VOTE_AVG, movie.vote_average)
        values.put(COL_TITLE, movie.title)
        values.put(COL_ORG_TITLE, movie.original_title)
        values.put(COL_ORG_LANG, movie.original_language)
        values.put(COL_OVERVIEW, movie.overview)
        values.put(COL_POPULARITY, movie.popularity)
        values.put(COL_POSTER, movie.poster_path)
        values.put(COL_BACKDROP, movie.backdrop_path)
        values.put(COL_VOTE_CNT, movie.vote_count)
        values.put(COL_RELEASE, movie.release_date)
        return db.update("movies", values, "COL_ID = ?", arrayOf(movie.db_id.toString()))
    }

    fun closeDB() {
        val db = this.readableDatabase
        if (db != null && db.isOpen) {
            db.close()
        }
    }
}