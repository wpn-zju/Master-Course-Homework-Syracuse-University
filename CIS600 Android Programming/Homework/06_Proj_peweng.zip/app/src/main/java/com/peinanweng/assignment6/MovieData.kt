package com.peinanweng.assignment6

import java.io.Serializable

data class MovieData(
    val vote_count: Int?,
    val id: Int?,
    val vote_average: Double?,
    var title: String?,
    val popularity: Double?,
    val poster_path: String?,
    val original_language: String?,
    val original_title: String?,
    val backdrop_path: String?,
    val overview: String?,
    val release_date: String?,
    var db_id: Int?,
) : Serializable
