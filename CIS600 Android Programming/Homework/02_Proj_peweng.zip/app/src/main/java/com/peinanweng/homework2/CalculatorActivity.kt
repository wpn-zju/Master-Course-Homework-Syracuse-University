package com.peinanweng.homework2

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_calculator.*
import kotlinx.android.synthetic.main.activity_main.toolbar
import java.math.BigDecimal
import java.util.*
import java.util.regex.Pattern

class CalculatorActivity : AppCompatActivity() {

    private var isOperatorDown: Boolean = false
    private var isDotDown: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_calculator)

        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        button_0.setOnClickListener { numDown("0") }
        button_1.setOnClickListener { numDown("1") }
        button_2.setOnClickListener { numDown("2") }
        button_3.setOnClickListener { numDown("3") }
        button_4.setOnClickListener { numDown("4") }
        button_5.setOnClickListener { numDown("5") }
        button_6.setOnClickListener { numDown("6") }
        button_7.setOnClickListener { numDown("7") }
        button_8.setOnClickListener { numDown("8") }
        button_9.setOnClickListener { numDown("9") }
        button_addition.setOnClickListener { operatorDown("+") }
        button_subtraction.setOnClickListener { operatorDown("-") }
        button_muliplication.setOnClickListener { operatorDown("×") }
        button_division.setOnClickListener { operatorDown("÷") }
        button_del.setOnClickListener {
            val str: String = text_edit.text.toString()
            val length: Int = str.length
            if (Pattern.matches("^=[0-9].*", str)) {
                text_edit.text = "0"
                text_result.text = ""
            } else {
                if (length > 0) {
                    when (str.substring(length - 1, length)) {
                        "." -> isDotDown = false
                        "+" -> isOperatorDown = false
                        "-" -> isOperatorDown = false
                        "×" -> isOperatorDown = false
                        "÷" -> isOperatorDown = false
                    }
                    text_edit.text = str.substring(0, length - 1)
                }
            }
        }
        button_ac.setOnClickListener {
            isDotDown = false
            isOperatorDown = false
            text_edit.text = "0"
            text_result.text = ""
        }
        button_dot.setOnClickListener {
            var str: String = text_edit.text.toString()
            if (!isDotDown) {
                isDotDown = true
                if (Pattern.matches("^=[0-9].*", str)) {
                    str = "0"
                }
                text_edit.text = String.format("%s.", str)
            }
        }
        button_equal.setOnClickListener { equal() }
    }

    private fun numDown(num: String) {
        val str: String = text_edit.text.toString()
        isOperatorDown = false
        if (str == "0" || Pattern.matches("^=[0-9].*", str)) {
            text_edit.text = num
            text_result.text = ""
        } else {
            text_edit.text = String.format("%s%s", str, num)
        }
    }

    private fun operatorDown(operator: String) {
        if (!isOperatorDown) {
            var str: String = text_edit.text.toString()
            isOperatorDown = true
            isDotDown = false
            if (Pattern.matches("^=[0-9].*", str))
                str = str.substring(1, str.length)
            text_edit.text = String.format("%s%s", str, operator)
        } else {
            val str: String = text_edit.text.toString()
            text_edit.text = String.format("%s%s", str.substring(0, str.length - 1), operator)
        }
    }

    private fun equal() {
        var str: String = text_edit.text.toString()
        if (!Pattern.matches("^=[0-9].*", str)) {
            text_result.text = str
            if (Pattern.matches(".*[\\+\\-\\×\\÷\\.]$", str)) {
                str = str.substring(0, str.length - 1)
            }
            val postfixExp: String = getPostfixExp(str)
            text_edit.text = String.format("=%s", calPostfix(postfixExp))
        }
    }

    private fun getPostfixExp(str: String): String {
        var postfix: String = ""
        var numString: String = ""
        val numStack: Stack<String> = Stack()
        val opStack: Stack<String> = Stack()
        for (i in 0 until str.length) {
            val ch: Char = str[i]
            if (Character.isDigit(ch) || ch == '.' || (i == 0 && ch == '-')) {
                numString += ch
            } else {
                if (numString.isNotEmpty()) {
                    numStack.push(numString)
                    numString = ""
                }
                opPush(opStack, numStack, ch)
            }
        }

        if (numString.isNotEmpty()) {
            numStack.push(numString)
        }

        while (!opStack.empty()) {
            numStack.push(opStack.pop())
        }

        while (!numStack.empty()) {
            opStack.push((numStack.pop()))
        }

        while (!opStack.empty()) {
            postfix = postfix + opStack.pop() + " "
        }

        return postfix
    }

    private fun calPostfix(str: String): String {
        var result: String = ""
        val numStack: Stack<String> = Stack()
        for (i in 0 until str.length) {
            val ch: Char = str[i]
            if (ch == ' ') {
                if (result.isNotEmpty() && (result == "+" || result == "-" || result == "×"|| result == "÷")) {
                    var num: Double = 0.0
                    val secondNum = numStack.pop().toDouble()
                    val firstNum = numStack.pop().toDouble()
                    when (result) {
                        "+" -> num = firstNum + secondNum
                        "-" -> num = firstNum - secondNum
                        "×" -> num = firstNum * secondNum
                        "÷" -> num = if(secondNum == 0.0) Double.NaN else firstNum / secondNum
                    }
                    numStack.push(num.toString())
                } else if (result.isNotEmpty()) {
                    numStack.push(result)
                }
                result = ""
            } else {
                result += ch
            }
        }
        return BigDecimal.valueOf(numStack.pop().toDouble()).stripTrailingZeros().toPlainString()
    }

    private fun getOpWeight(ch: Char): Int {
        return when (ch) {
            '+' -> 1
            '-' -> 1
            '×' -> 2
            '÷' -> 2
            else -> 0
        }
    }

    private fun opPush(opStack: Stack<String>, numStack: Stack<String>, ch: Char) {
        if (canOpPush(opStack, ch)) {
            opStack.push(ch.toString())
        } else {
            numStack.push(opStack.pop())
            opPush(opStack, numStack, ch)
        }
    }

    private fun canOpPush(opStack: Stack<String>, ch: Char): Boolean {
        return opStack.empty() || (getOpWeight(ch) > getOpWeight(opStack.peek()[0]))
    }
}
