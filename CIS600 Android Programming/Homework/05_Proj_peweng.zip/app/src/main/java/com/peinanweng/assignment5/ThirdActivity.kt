package com.peinanweng.assignment5

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_third.*
import kotlinx.android.synthetic.main.layout_toolbar.*

class ThirdActivity : AppCompatActivity(), RecyclerFragment.OnRecyclerInteractionListener {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_third)

        setSupportActionBar(toolbar)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowTitleEnabled(false)

        toolbar.setLogo(R.drawable.ic_baseline_local_movies_24)
        toolbar.setTitle(R.string.movie_list)

        supportFragmentManager.beginTransaction().add(R.id.frame_master, RecyclerFragment.newInstance(true)).commit()

        bottom_bar.inflateMenu(R.menu.menu_task3_bottom)
    }

    override fun onItemClicked(movie: MovieData) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.frame_master, MovieFragment.newInstance(movie))
            .addToBackStack(null).commit()
    }
}