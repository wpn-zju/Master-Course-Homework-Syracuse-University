package com.peinanweng.assignment5

import android.content.Intent
import android.os.Bundle
import android.view.*
import androidx.appcompat.widget.ShareActionProvider
import androidx.core.view.MenuItemCompat
import com.peinanweng.assignment5.databinding.FragmentMovieBinding
import java.io.Serializable

private const val ARG_MOV1 = "movie"

class MovieFragment : androidx.fragment.app.Fragment() {
    private lateinit var movieData: MovieData
    private lateinit var binding: FragmentMovieBinding

    companion object {
        @JvmStatic
        fun newInstance(movie: MovieData) =
            MovieFragment().apply {
                arguments = Bundle().apply {
                    putSerializable(ARG_MOV1, movie as Serializable)
                }
            }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        arguments?.let {
            movieData = it.getSerializable(ARG_MOV1) as MovieData
        }

        setHasOptionsMenu(true)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        binding = FragmentMovieBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.movieFragTitle.text = movieData.title
        binding.movieFragYear.text = movieData.release_date
        binding.movieFragPreview.setImageResource(movieData.poster_id)
        binding.movieFragRating.rating = movieData.vote_average.toFloat() / 2
        binding.movieFragStar.text = String.format("Vote Count: %d", movieData.vote_count)
        binding.movieFragDescription.text = movieData.overview
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.menu_task2_movie, menu)
        val shareItem = menu.findItem(R.id.action_share)
        val mShareActionProvider = MenuItemCompat.getActionProvider(shareItem) as ShareActionProvider
        val intentShare = Intent(Intent.ACTION_SEND)
        intentShare.type = "text/plain"
        intentShare.putExtra(Intent.EXTRA_TEMPLATE, movieData.title)
        mShareActionProvider.setShareIntent(intentShare)
        super.onCreateOptionsMenu(menu, inflater)
    }
}
