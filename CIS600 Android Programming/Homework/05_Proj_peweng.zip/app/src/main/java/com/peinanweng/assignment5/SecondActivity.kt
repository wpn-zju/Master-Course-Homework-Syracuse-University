package com.peinanweng.assignment5

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.layout_toolbar.*

class SecondActivity : AppCompatActivity(), RecyclerFragment.OnRecyclerInteractionListener {
    private lateinit var selectedMovieData: MovieData

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)

        setSupportActionBar(toolbar)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowTitleEnabled(false)

        toolbar.setLogo(R.drawable.ic_baseline_local_movies_24)
        toolbar.setTitle(R.string.movie_list)

        supportFragmentManager.beginTransaction().add(R.id.frame_master, RecyclerFragment.newInstance(false)).commit()
    }

    override fun onItemClicked(movie: MovieData) {
        selectedMovieData = movie
        toolbar.title = selectedMovieData.title
        supportFragmentManager.beginTransaction()
            .replace(R.id.frame_master, MovieFragment.newInstance(movie))
            .addToBackStack(null).commit()
    }
}