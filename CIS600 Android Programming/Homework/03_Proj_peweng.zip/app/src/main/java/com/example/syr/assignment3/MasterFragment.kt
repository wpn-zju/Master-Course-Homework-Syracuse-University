package com.example.syr.assignment3

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import kotlinx.android.synthetic.main.fragment_master.*

class MasterFragment : androidx.fragment.app.Fragment() {
    private var listener: OnMasterDetailListener? = null

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        btnBook1.setOnClickListener { onButtonPressed(0) }
        btnBook2.setOnClickListener { onButtonPressed(1) }
        btnBook3.setOnClickListener { onButtonPressed(2) }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_master, container, false)
    }

    private fun onButtonPressed(index: Int) {
        listener?.onBookSelect(index)
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        if (context is OnMasterDetailListener) {
            listener = context
        } else {
            throw RuntimeException("$context must implement OnMasterDetailListener")
        }
    }

    override fun onDetach() {
        super.onDetach()
        listener = null
    }

    interface OnMasterDetailListener {
        fun onBookSelect(index: Int)
    }
}
