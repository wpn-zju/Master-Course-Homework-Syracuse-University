package com.example.syr.assignment3

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.google.android.material.tabs.TabLayoutMediator
import kotlinx.android.synthetic.main.activity_text_tab_vp.*

class TextTabViewPagerActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_text_tab_vp)

        setSupportActionBar(myToolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val adapter = MoviePageAdapter(this)

        viewPager.adapter = adapter
        viewPager.currentItem = 0
        TabLayoutMediator(tabPanel, viewPager) { tab, position ->
            tab.text = adapter.getTitle(position)
        }.attach()
    }
}
