package com.example.syr.assignment3

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import kotlinx.android.synthetic.main.fragment_movie.*
import java.io.Serializable

private const val ARG_MOV1 = "movie"
private const val ARG_MOV2 = "poster"

class MovieFragment : androidx.fragment.app.Fragment() {
    private lateinit var movieData: MovieData
    private var poster: Int = -1

    companion object {
        @JvmStatic
        fun newInstance(param1: MovieData, param2: Int) =
                MovieFragment().apply {
                    arguments = Bundle().apply {
                        putSerializable(ARG_MOV1, param1 as Serializable)
                        putInt(ARG_MOV2, param2)
                    }
                }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        arguments?.let {
            movieData = it.getSerializable(ARG_MOV1) as MovieData
            poster = it.getInt(ARG_MOV2)
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_movie, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        movie_frag_title.text = movieData.title
        movie_frag_year.text = movieData.release_date
        movie_frag_preview.setImageResource(poster)
        movie_frag_rating.rating = movieData.vote_average.toFloat() / 2
        movie_frag_star.text = String.format("Vote Count: %d", movieData.vote_count)
        movie_frag_description.text = movieData.overview
    }
}
