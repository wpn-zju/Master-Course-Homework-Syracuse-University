package com.peinanweng.helloworld

import android.content.res.Configuration
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val text = findViewById<TextView>(R.id.text2)
        val image = findViewById<ImageView>(R.id.image)

        val orientation = resources.configuration.orientation;
        if (orientation == Configuration.ORIENTATION_LANDSCAPE) {
            text.setText(R.string.introduction)
            image.setImageResource(R.drawable.pic_2015)
        } else if (orientation == Configuration.ORIENTATION_PORTRAIT) {
            text.setText(R.string.hint)
            image.setImageResource(R.drawable.pic_2019)
        }

        val rollButton = findViewById<Button>(R.id.button)
        rollButton.setText(R.string.button);
        rollButton.setOnClickListener {
            Toast.makeText(this, R.string.toastHint, Toast.LENGTH_LONG).show()
        }
    }
}
