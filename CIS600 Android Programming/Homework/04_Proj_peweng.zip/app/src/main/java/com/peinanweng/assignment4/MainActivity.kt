package com.peinanweng.assignment4

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        setSupportActionBar(myToolbar)

        val appBar = supportActionBar
        appBar!!.title = getString(R.string.app_name)

        aboutMe.setOnClickListener{
            val fragment: androidx.fragment.app.Fragment? = supportFragmentManager.findFragmentById(R.id.meContainer)
            if (fragment == null) {
                supportFragmentManager.beginTransaction().add(R.id.meContainer, AboutMeFragment()).commit()
            } else {
                supportFragmentManager.beginTransaction().remove(fragment).commit()
            }
        }

        button_recycler_view.setOnClickListener{
             val intent = Intent(this, RecyclerActivity::class.java)
             startActivity(intent)
        }
    }
}
