package com.peinanweng.assignment4

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.gson.Gson
import jp.wasabeef.recyclerview.adapters.AlphaInAnimationAdapter
import jp.wasabeef.recyclerview.adapters.ScaleInAnimationAdapter
import jp.wasabeef.recyclerview.animators.SlideInLeftAnimator
import kotlinx.android.synthetic.main.fragment_recycler.*

class RecyclerFragment : Fragment(), MovieRecyclerViewAdapter.MyItemClickListener {
    private var movieList: List<MovieData> = Gson().fromJson(movies, Array<MovieData>::class.java).asList()
    private val myAdapter = ScaleInAnimationAdapter(MovieRecyclerViewAdapter(ArrayList(movieList)))

    init {
        movieList[0].poster_id = R.drawable.moneyplane
        movieList[1].poster_id = R.drawable.mulan
        movieList[2].poster_id = R.drawable.santana
        movieList[3].poster_id = R.drawable.hardkill
        movieList[4].poster_id = R.drawable.rogue
        movieList[5].poster_id = R.drawable.unknownorigins
        movieList[6].poster_id = R.drawable.peninsula
        movieList[7].poster_id = R.drawable.projectpower
        movieList[8].poster_id = R.drawable.afterwecollided
        movieList[9].poster_id = R.drawable.onenightinbangkok
    }

    private var listener: OnRecyclerInteractionListener? = null

    fun setListener(listener: OnRecyclerInteractionListener) {
        this.listener = listener
    }

    interface OnRecyclerInteractionListener {
        fun onItemClicked(movie: MovieData)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val layoutManager: RecyclerView.LayoutManager
        layoutManager = LinearLayoutManager(view.context)

        recycler_view.hasFixedSize()
        recycler_view.layoutManager = layoutManager

        (myAdapter.wrappedAdapter as MovieRecyclerViewAdapter).setMyItemClickListener(this)
        recycler_view.adapter = myAdapter

        recycler_view.itemAnimator = SlideInLeftAnimator()
        recycler_view.itemAnimator?.addDuration = 1000L
        recycler_view.itemAnimator?.removeDuration = 1000L
        recycler_view.itemAnimator?.moveDuration = 1000L
        recycler_view.itemAnimator?.changeDuration = 1000L

        button_select_all.setOnClickListener {
            (myAdapter.wrappedAdapter as MovieRecyclerViewAdapter).setSelectAll()
        }

        button_clear_all.setOnClickListener {
            (myAdapter.wrappedAdapter as MovieRecyclerViewAdapter).setClearAll()
        }

        button_delete.setOnClickListener {
            (myAdapter.wrappedAdapter as MovieRecyclerViewAdapter).deleteMovies()
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_recycler, container, false)
    }

    override fun onItemClickedFromAdapter(movie: MovieData) {
        onItemClickedFromRecyclerViewFragment(movie)
    }

    private fun onItemClickedFromRecyclerViewFragment(movie: MovieData) {
        listener?.onItemClicked(movie)
    }

    override fun onItemLongClickedFromAdapter(position: Int) {
        (myAdapter.wrappedAdapter as MovieRecyclerViewAdapter).addMovie(position)
        myAdapter.notifyItemInserted(position + 1)
    }
}

private const val movies = "[{\n" +
        "        \"popularity\": 2185.128,\n" +
        "        \"vote_count\": 786,\n" +
        "        \"video\": false,\n" +
        "        \"poster_path\": \"\\/6CoRTJTmijhBLJTUNoVSUNxZMEI.jpg\",\n" +
        "        \"id\": 694919,\n" +
        "        \"adult\": false,\n" +
        "        \"backdrop_path\": \"\\/gYRzgYE3EOnhUkv7pcbAAsVLe5f.jpg\",\n" +
        "        \"original_language\": \"en\",\n" +
        "        \"original_title\": \"Money Plane\",\n" +
        "        \"genre_ids\": [28],\n" +
        "        \"title\": \"Money Plane\",\n" +
        "        \"vote_average\": 8.4,\n" +
        "        \"overview\": \"A professional thief with \$40 million in debt and his family's life on the line must commit one final heist - rob a futuristic airborne casino filled with the world's most dangerous criminals.\",\n" +
        "        \"release_date\": \"2020-09-29\"\n" +
        "    }, {\n" +
        "        \"popularity\": 1919.377,\n" +
        "        \"vote_count\": 1756,\n" +
        "        \"video\": false,\n" +
        "        \"poster_path\": \"\\/aKx1ARwG55zZ0GpRvU2WrGrCG9o.jpg\",\n" +
        "        \"id\": 337401,\n" +
        "        \"adult\": false,\n" +
        "        \"backdrop_path\": \"\\/zzWGRw277MNoCs3zhyG3YmYQsXv.jpg\",\n" +
        "        \"original_language\": \"en\",\n" +
        "        \"original_title\": \"Mulan\",\n" +
        "        \"genre_ids\": [28, 12, 18, 14, 10752],\n" +
        "        \"title\": \"Mulan\",\n" +
        "        \"vote_average\": 7.5,\n" +
        "        \"overview\": \"When the Emperor of China issues a decree that one man per family must serve in the Imperial Chinese Army to defend the country from Huns, Hua Mulan, the eldest daughter of an honored warrior, steps in to take the place of her ailing father. She is spirited, determined and quick on her feet. Disguised as a man by the name of Hua Jun, she is tested every step of the way and must harness her innermost strength and embrace her true potential.\",\n" +
        "        \"release_date\": \"2020-09-10\"\n" +
        "    }, {\n" +
        "        \"popularity\": 1134.108,\n" +
        "        \"vote_count\": 80,\n" +
        "        \"video\": false,\n" +
        "        \"poster_path\": \"\\/9Rj8l6gElLpRL7Kj17iZhrT5Zuw.jpg\",\n" +
        "        \"id\": 734309,\n" +
        "        \"adult\": false,\n" +
        "        \"backdrop_path\": \"\\/7fvdg211A2L0mHddvzyArRuRalp.jpg\",\n" +
        "        \"original_language\": \"en\",\n" +
        "        \"original_title\": \"Santana\",\n" +
        "        \"genre_ids\": [28],\n" +
        "        \"title\": \"Santana\",\n" +
        "        \"vote_average\": 5.6,\n" +
        "        \"overview\": \"Two brothers — one a narcotics agent and the other a general — finally discover the identity of the drug lord who murdered their parents decades ago. They may kill each other before capturing the bad guys.\",\n" +
        "        \"release_date\": \"2020-08-28\"\n" +
        "    }, {\n" +
        "        \"popularity\": 1067.038,\n" +
        "        \"vote_count\": 72,\n" +
        "        \"video\": false,\n" +
        "        \"poster_path\": \"\\/ugZW8ocsrfgI95pnQ7wrmKDxIe.jpg\",\n" +
        "        \"id\": 724989,\n" +
        "        \"adult\": false,\n" +
        "        \"backdrop_path\": \"\\/86L8wqGMDbwURPni2t7FQ0nDjsH.jpg\",\n" +
        "        \"original_language\": \"en\",\n" +
        "        \"original_title\": \"Hard Kill\",\n" +
        "        \"genre_ids\": [28, 53],\n" +
        "        \"title\": \"Hard Kill\",\n" +
        "        \"vote_average\": 5.2,\n" +
        "        \"overview\": \"The work of billionaire tech CEO Donovan Chalmers is so valuable that he hires mercenaries to protect it, and a terrorist group kidnaps his daughter just to get it.\",\n" +
        "        \"release_date\": \"2020-08-25\"\n" +
        "    }, {\n" +
        "        \"popularity\": 910.434,\n" +
        "        \"vote_count\": 225,\n" +
        "        \"video\": false,\n" +
        "        \"poster_path\": \"\\/uOw5JD8IlD546feZ6oxbIjvN66P.jpg\",\n" +
        "        \"id\": 718444,\n" +
        "        \"adult\": false,\n" +
        "        \"backdrop_path\": \"\\/x4UkhIQuHIJyeeOTdcbZ3t3gBSa.jpg\",\n" +
        "        \"original_language\": \"en\",\n" +
        "        \"original_title\": \"Rogue\",\n" +
        "        \"genre_ids\": [28],\n" +
        "        \"title\": \"Rogue\",\n" +
        "        \"vote_average\": 5.9,\n" +
        "        \"overview\": \"Battle-hardened O’Hara leads a lively mercenary team of soldiers on a daring mission: rescue hostages from their captors in remote Africa. But as the mission goes awry and the team is stranded, O’Hara’s squad must face a bloody, brutal encounter with a gang of rebels.\",\n" +
        "        \"release_date\": \"2020-08-20\"\n" +
        "    }, {\n" +
        "        \"popularity\": 859.153,\n" +
        "        \"vote_count\": 154,\n" +
        "        \"video\": false,\n" +
        "        \"poster_path\": \"\\/sMO1v5TUf8GOJHbJieDXsgWT2Ud.jpg\",\n" +
        "        \"id\": 438396,\n" +
        "        \"adult\": false,\n" +
        "        \"backdrop_path\": \"\\/qGZe9qTuydxyJYQ60XDtEckzLR8.jpg\",\n" +
        "        \"original_language\": \"es\",\n" +
        "        \"original_title\": \"Orígenes secretos\",\n" +
        "        \"genre_ids\": [18, 53],\n" +
        "        \"title\": \"Unknown Origins\",\n" +
        "        \"vote_average\": 6.2,\n" +
        "        \"overview\": \"In Madrid, Spain, a mysterious serial killer ruthlessly murders his victims by recreating the first appearance of several comic book superheroes. Cosme, a veteran police inspector who is about to retire, works on the case along with the tormented inspector David Valentín and his own son Jorge Elías, a nerdy young man who owns a comic book store.\",\n" +
        "        \"release_date\": \"2020-08-28\"\n" +
        "    }, {\n" +
        "        \"popularity\": 855.316,\n" +
        "        \"vote_count\": 462,\n" +
        "        \"video\": false,\n" +
        "        \"poster_path\": \"\\/sy6DvAu72kjoseZEjocnm2ZZ09i.jpg\",\n" +
        "        \"id\": 581392,\n" +
        "        \"adult\": false,\n" +
        "        \"backdrop_path\": \"\\/gEjNlhZhyHeto6Fy5wWy5Uk3A9D.jpg\",\n" +
        "        \"original_language\": \"ko\",\n" +
        "        \"original_title\": \"반도\",\n" +
        "        \"genre_ids\": [28, 27, 53],\n" +
        "        \"title\": \"Peninsula\",\n" +
        "        \"vote_average\": 7.1,\n" +
        "        \"overview\": \"A soldier and his team battle hordes of post-apocalyptic zombies in the wastelands of the Korean Peninsula.\",\n" +
        "        \"release_date\": \"2020-07-15\"\n" +
        "    }, {\n" +
        "        \"popularity\": 674.842,\n" +
        "        \"vote_count\": 1238,\n" +
        "        \"video\": false,\n" +
        "        \"poster_path\": \"\\/TnOeov4w0sTtV2gqICqIxVi74V.jpg\",\n" +
        "        \"id\": 605116,\n" +
        "        \"adult\": false,\n" +
        "        \"backdrop_path\": \"\\/qVygtf2vU15L2yKS4Ke44U4oMdD.jpg\",\n" +
        "        \"original_language\": \"en\",\n" +
        "        \"original_title\": \"Project Power\",\n" +
        "        \"genre_ids\": [28, 80, 878],\n" +
        "        \"title\": \"Project Power\",\n" +
        "        \"vote_average\": 6.7,\n" +
        "        \"overview\": \"An ex-soldier, a teen and a cop collide in New Orleans as they hunt for the source behind a dangerous new pill that grants users temporary superpowers.\",\n" +
        "        \"release_date\": \"2020-08-14\"\n" +
        "    }, {\n" +
        "        \"popularity\": 575.679,\n" +
        "        \"vote_count\": 306,\n" +
        "        \"video\": false,\n" +
        "        \"poster_path\": \"\\/kiX7UYfOpYrMFSAGbI6j1pFkLzQ.jpg\",\n" +
        "        \"id\": 613504,\n" +
        "        \"adult\": false,\n" +
        "        \"backdrop_path\": \"\\/r5srC0cqU36n38azFnCyReEksiR.jpg\",\n" +
        "        \"original_language\": \"en\",\n" +
        "        \"original_title\": \"After We Collided\",\n" +
        "        \"genre_ids\": [18, 10749],\n" +
        "        \"title\": \"After We Collided\",\n" +
        "        \"vote_average\": 6.8,\n" +
        "        \"overview\": \"Tessa finds herself struggling with her complicated relationship with Hardin; she faces a dilemma that could change their lives forever.\",\n" +
        "        \"release_date\": \"2020-09-02\"\n" +
        "    }, {\n" +
        "        \"popularity\": 565.459,\n" +
        "        \"vote_count\": 81,\n" +
        "        \"video\": false,\n" +
        "        \"poster_path\": \"\\/i4kPwXPlM1iy8Jf3S1uuLuwqQAV.jpg\",\n" +
        "        \"id\": 721452,\n" +
        "        \"adult\": false,\n" +
        "        \"backdrop_path\": \"\\/riDrpqQtZpXGeiJdlmfcwwPH7nN.jpg\",\n" +
        "        \"original_language\": \"en\",\n" +
        "        \"original_title\": \"One Night in Bangkok\",\n" +
        "        \"genre_ids\": [28, 53],\n" +
        "        \"title\": \"One Night in Bangkok\",\n" +
        "        \"vote_average\": 7.3,\n" +
        "        \"overview\": \"A hit man named Kai flies into Bangkok, gets a gun, and orders a cab. He offers a professional female driver big money to be his all-night driver. But when she realizes Kai is committing brutal murders at each stop, it's too late to walk away. Meanwhile, an offbeat police detective races to decode the string of slayings before more blood is spilled.\",\n" +
        "        \"release_date\": \"2020-08-25\"\n" +
        "    }]"
