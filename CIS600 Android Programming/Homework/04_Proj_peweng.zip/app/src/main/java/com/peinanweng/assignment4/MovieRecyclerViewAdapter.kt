package com.peinanweng.assignment4

import android.animation.Animator
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import jp.wasabeef.recyclerview.animators.holder.AnimateViewHolder

@Suppress("unused")
class MovieRecyclerViewAdapter(val items: ArrayList<MovieData>) : RecyclerView.Adapter<MovieRecyclerViewAdapter.MovieViewHolder>() {
    var myListener: MyItemClickListener? = null
    private var lastPosition = -1

    interface MyItemClickListener {
        fun onItemClickedFromAdapter(movie: MovieData)
        fun onItemLongClickedFromAdapter(position: Int)
    }

    fun setMyItemClickListener (listener: MyItemClickListener) {
        this.myListener = listener
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MovieViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        val view: View

        view = when (viewType) {
            1 -> {
                layoutInflater.inflate(R.layout.layout_card_left, parent, false)
            }
            2 -> {
                layoutInflater.inflate(R.layout.layout_card_right, parent, false)
            }
            else -> {
                layoutInflater.inflate(R.layout.layout_card_right, parent, false)
            }
        }

        return MovieViewHolder(view)
    }

    override fun getItemCount(): Int {
        return items.size
    }

    override fun onBindViewHolder(holder: MovieViewHolder, position: Int) {
        val movie = items[position]
        holder.moviePoster.setImageResource(movie.poster_id)
        holder.movieTitle.text = movie.title
        var length = movie.overview.length
        length = if (length > 150) 150 else length
        holder.movieOverview.text = String.format("%s ...", movie.overview.substring(0, length - 1))
        holder.movieSelect.isChecked = movie.checked
    }

    override fun getItemViewType(position: Int): Int {
        return if (items[position].vote_average >= 6) 1 else 2
    }

    fun setClearAll() {
        for (i in items.indices) {
            items[i].checked = false
        }
        notifyItemRangeChanged(0, items.size - 1)
    }

    fun setSelectAll() {
        for (i in items.indices) {
            items[i].checked = true
        }
        notifyItemRangeChanged(0, items.size - 1)
    }

    fun addMovie(position: Int) {
        items.add(position + 1, items[position].copy())
        items[position + 1].title = String.format("Copy of %s", items[position].title)
    }

    fun addMovies() {
        for (i in items.indices) {
            val movie = items[i].copy()
            if (movie.checked) {
                items[i].checked = false
                movie.checked = false
                movie.title = String.format("Copy of %s", movie.title)
                items.add(i + 1, movie)
                notifyItemInserted(i + 1)
            }
        }
    }

    fun deleteMovie(position: Int) {
        items.removeAt(position)
    }

    fun deleteMovies() {
        var cnt = 0
        for (i in 0 until items.size) {
            if (items[i].checked) {
                cnt += 1
            }
        }

        for (i in 0 until cnt) {
            for (j in items.indices) {
                if (items[j].checked) {
                    items.removeAt(j)
                    notifyItemRemoved(j)
                    break
                }
            }
        }
    }

    fun sortMovies() {
        items.sortWith { p0, p1 -> p0!!.title.compareTo(p1!!.title, true) }
        notifyItemRangeChanged(0, items.size - 1)
    }

    inner class MovieViewHolder(view: View) : RecyclerView.ViewHolder(view), AnimateViewHolder {
        val moviePoster: ImageView = view.findViewById(R.id.rvPoster)
        val movieTitle: TextView = view.findViewById(R.id.rvTitle)
        val movieOverview: TextView = view.findViewById(R.id.rvOverview)
        val movieSelect: CheckBox = view.findViewById(R.id.rvChx)

        init {
            movieSelect.setOnCheckedChangeListener { _, isChecked ->
                items[adapterPosition].checked = isChecked
            }

            view.setOnClickListener {
                if (myListener != null) {
                    if (adapterPosition != RecyclerView.NO_POSITION) {
                        myListener!!.onItemClickedFromAdapter(items[adapterPosition])
                    }
                }
            }
            view.setOnLongClickListener {
                if (myListener != null) {
                    if (adapterPosition != RecyclerView.NO_POSITION) {
                        myListener!!.onItemLongClickedFromAdapter(adapterPosition)
                    }
                }
                true
            }
        }

        override fun preAnimateRemoveImpl(holder: RecyclerView.ViewHolder) {
            
        }

        override fun animateRemoveImpl(
            holder: RecyclerView.ViewHolder,
            listener: Animator.AnimatorListener
        ) {
            itemView.animate().apply {
                translationY(-itemView.height * 0.3f)
                alpha(0f)
                duration = 300
                setListener(listener)
            }.start()
        }

        override fun preAnimateAddImpl(holder: RecyclerView.ViewHolder) {
            itemView.translationY = -itemView.height * 0.3f
            itemView.alpha = 0f
        }

        override fun animateAddImpl(
            holder: RecyclerView.ViewHolder,
            listener: Animator.AnimatorListener
        ) {
            itemView.animate().apply {
                translationY(0f)
                alpha(1f)
                duration = 300
                setListener(listener)
            }.start()
        }
    }
}
