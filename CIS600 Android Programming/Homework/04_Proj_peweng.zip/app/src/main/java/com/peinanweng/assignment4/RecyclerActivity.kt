package com.peinanweng.assignment4

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_recycler.*

class RecyclerActivity : AppCompatActivity(), RecyclerFragment.OnRecyclerInteractionListener {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_recycler)

        setSupportActionBar(myToolbar)

        if (savedInstanceState == null) {
            val recyclerFragment = RecyclerFragment()
            recyclerFragment.setListener(this)
            supportFragmentManager.beginTransaction().replace(R.id.mContainer, recyclerFragment).commit()
        }
    }

    override fun onItemClicked(movie: MovieData) {
        supportFragmentManager.beginTransaction().replace(R.id.mContainer, MovieFragment.newInstance(movie)).addToBackStack(null).commit()
    }
}
