mkdir Assignment-1
for i in {1..10}
do
	mkdir Assignment-1/Query-$i
	touch Assignment-1/Query-$i/response-$i.sh
done
