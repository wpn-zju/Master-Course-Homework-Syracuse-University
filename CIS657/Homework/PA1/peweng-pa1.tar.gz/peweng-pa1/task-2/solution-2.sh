for file in `find . -name "*.c"`
do
	tar -rf allcfiles.tar -C ${file%/*} ${file##*/}
done
