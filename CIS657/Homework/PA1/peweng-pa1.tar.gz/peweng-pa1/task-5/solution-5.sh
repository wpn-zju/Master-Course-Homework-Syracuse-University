wget $1

tar -xf sample_data.tar

mkdir smart
mkdir OS

cd sample_data

for file in `ls`
do
	if [ -f "$file" ]
	then
		echo $file "smart" $(grep -c "smart" $file) >> ../result.txt
	fi
done

for file in `ls`
do
	if [ -f "$file" ]
	then
		echo $file "operating system" $(grep -c "operating system" $file) >> ../result.txt
	fi
done

for file in `ls`
do
	if [ -f "$file" ]
	then
		if [ "$(grep -c "smart" $file)" -gt 0 ]
		then
			cp $file ../smart
		fi
		if [ "$(grep -c "operating system" $file)" -gt 0 ]
		then
			cp $file ../OS
		fi
	fi
done
