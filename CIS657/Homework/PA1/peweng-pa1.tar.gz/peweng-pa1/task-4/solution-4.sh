ps -f | grep 'infloop' | grep -v grep | awk -F ' ' '{print $2}' | xargs kill
