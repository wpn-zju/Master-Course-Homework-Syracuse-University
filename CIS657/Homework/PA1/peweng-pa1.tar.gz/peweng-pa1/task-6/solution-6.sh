tar -xzf input.tar.gz
mkdir TXT
mkdir JPG
mkdir ZIP
mv input/*.txt TXT
mv input/*.jpg JPG
find input -maxdepth 1 -type f | xargs -i mv {} ZIP
tar -czf rest_zipped.tar.gz ZIP
