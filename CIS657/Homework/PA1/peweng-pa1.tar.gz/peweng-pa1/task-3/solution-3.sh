cat /proc/cpuinfo | grep -c 'processor' >> cpuinfo.txt
cat /proc/cpuinfo | grep 'core id' | awk -F ':' '{print $2}' | awk -F ' ' '{print $1}' >> cpuinfo.txt
cat /proc/cpuinfo | grep 'cache size' | awk -F ':' '{print $2}' | awk -F ' ' '{print $1}' >> cpuinfo.txt
