/* Your code goes here */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#define BUFLEN 1024

char dic[16] = {'0','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f'};

char* bin2hex(char* input){
	char* output = (char*)malloc(sizeof(char) * BUFLEN);
	int indexi = 0;
	int indexo = 0;
	while(input[indexi] != '\0') {
		int digit = 
			((input[indexi + 0] - '0') << 3) +
			((input[indexi + 1] - '0') << 2) +
			((input[indexi + 2] - '0') << 1) + 
			((input[indexi + 3] - '0') << 0);
		indexi += 4;
		output[indexo++] = dic[digit];
	}
	output[indexo] = '\n';
	++indexo;
	output[indexo] = '\0';
	return output;
}

int main(int argc, char** argv){
	// Open File - Read Only
	FILE* in = fopen(argv[1], "r");
	if(!in){
		fprintf(stderr, "An error has occurred\n");
		exit(1);
	}
	
	FILE* out = fopen(argv[2], "w");
	if(!out){
		fprintf(stderr, "An error has occurred\n");
		exit(1);
	}

	char* line = (char*)malloc(sizeof(char) * BUFLEN);

	while(fgets(line, BUFLEN, in) != NULL) {
		// Delete the last character '\n' in each line.
		char* find = strchr(line, '\n');
		if(find)
			*find = '\0';

		char* bin = bin2hex(line);
		fputs(bin, out);

		memset(line, 0, BUFLEN);
	}

	fclose(in);
	fclose(out);

	return 0;
}
