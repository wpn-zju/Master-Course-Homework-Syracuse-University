/* Your code goes here */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#define BUFLEN 1024

unsigned int getwu(FILE* fp) {
	unsigned int u;
	char* s = (char*)&u;
	for(int i = 0; i < 4; ++i)
		s[i] = fgetc(fp);
	return u;
}

void putwu(FILE* fp, unsigned int u) {
	char* s = (char*)&u;
	for(int i = 0; i < 4; ++i)
		fputc(s[i], fp);
}

struct record {
	unsigned int value[25];
};

int cmpfunc(const void* a, const void* b) {
	struct record* ap = (struct record*)a;
	struct record* bp = (struct record*)b;
	return ap->value[0] - bp->value[0];
}

int main(int argc, char** argv){
	if(argc != 3){
		fprintf(stderr, "usage: %s binary_filename\n", argv[0]);
		exit(1);
	}

	// Open File - Read Only
	FILE* in = fopen(argv[1], "r");
	if(!in){
		fprintf(stderr, "Error: Cannot open file %s\n", argv[1]);
		exit(1);
	}
	
	FILE* out = fopen(argv[2], "w");
	if(!out){
		fprintf(stderr, "Error: Cannot open file %s\n", argv[2]);
		exit(1);
	}

	// Get Size
	struct stat statbuf;
	stat(argv[1], &statbuf);
	int count = statbuf.st_size / sizeof(struct record);
	struct record* rec = (struct record*)malloc(sizeof(struct record) * count);

	for(int i = 0; i < count; ++i)
		for(int n = 0; n < 25; ++n)
			rec[i].value[n] = getwu(in);
	
	qsort(rec, count, sizeof(struct record), cmpfunc);

	for(int i = 0; i < count; ++i)
		for(int n = 0; n < 25; ++n)
			putwu(out, rec[i].value[n]);
	
	fclose(in);
	fclose(out);
	
	return 0;
}
