/* Your code goes here */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#define BUFLEN 1024

int main(int argc, char** argv){
	// Open File - Read Only
	FILE* fp = fopen(argv[1], "r");
	if(!fp){
		fprintf(stderr, "An error has occurred\n");
		exit(1);
	}

	int linecount = 0;
	char* line = (char*)malloc(sizeof(char) * BUFLEN);
	char*** text = (char***)malloc(sizeof(char**) * BUFLEN);

	while(fgets(line, BUFLEN, fp) != NULL) {
		// Delete the last character '\n' in each line.
		char* find = strchr(line, '\n');
		if(find)
			*find = '\0';

		int count = 0;
		char* tmp;
		char** command = (char**)malloc(sizeof(char*) * BUFLEN);
		
		tmp = strtok(line, "\t ");
		command[count] = (char*)malloc(sizeof(char) * strlen(tmp));
		memcpy(command[count], tmp, strlen(tmp));
		++count;
		while(1) {
			tmp = strtok(NULL, "\t ");		

			if(!tmp)
				break;	

			command[count] = (char*)malloc(sizeof(char) * strlen(tmp));
			memcpy(command[count], tmp, strlen(tmp));
			++count;
		}

		text[linecount++] = command;
		
		memset(line, 0, BUFLEN);
	}

	fclose(fp);

	// Shell Execution
	for(int i =0 ;i < linecount;++i){
		int pid = fork();
		int status;
		if(pid == 0) {
			execvp(text[i][0], text[i]);
			exit(0);
		}
		else {
			waitpid(pid, &status, 0);
		}
	}
	
	return 0;
}
