/* Your code goes here */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#define BUFLEN 1024

int main(int argc, char** argv){
	char* line = (char*)malloc(sizeof(char) * BUFLEN);

	while(fgets(line, BUFLEN, stdin)) {
		char* tmp = strtok(line, "\t\n ");
		if(strcmp(tmp, "exit") == 0)
			break;
		else
			printf("%s\n", tmp);
		while(1) {
			tmp = strtok(NULL, "\t\n ");		
			if(tmp)
				printf("%s\n", tmp);
			else
				break;
		}
		
		memset(line, 0, BUFLEN);
	}

	return 0;
}
