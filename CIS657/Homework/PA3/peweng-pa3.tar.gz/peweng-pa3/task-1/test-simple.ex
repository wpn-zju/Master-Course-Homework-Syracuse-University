tinyshell> /bin/ps
tinyshell> /bin/ps
tinyshell> /usr/share/locale/ps
tinyshell>  8 17 94 ./test-simple.in
tinyshell> tinyshell> /tmp
tinyshell> 
Usage:
 ps [options]

 Try 'ps --help <simple|list|output|threads|misc|all>'
  or 'ps --help <s|l|o|t|m|a>'
 for additional help text.

For more details see ps(1).
tinyshell> 