tinyshell> chdir: No such file or directory
An error has occurred
tinyshell> An error has occurred
tinyshell> execvp: No such file or directory
An error has occurred
tinyshell> 
